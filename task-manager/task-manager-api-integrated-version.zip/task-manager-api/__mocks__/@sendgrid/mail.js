module.exports = {
    setApiKey(){
        
    },
    send(){

    }
}