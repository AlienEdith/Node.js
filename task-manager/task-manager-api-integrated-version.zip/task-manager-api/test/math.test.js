// const { calculateTip, fahrenheitToCelsius, celsiusToFahrenheit, add } = require('../src/math')

test('Test Name/Description', () => {
    // throw Error => failure, otherwise, success
    // throw new Error('detail description of error')
})

// test('Should calculate total with tip', () => {
//     const total = calculateTip(10, 0.3)
//     expect(total).toBe(13)
// })

// test('Should convert 32 F to 0 C', () => {
//     expect(fahrenheitToCelsius(32)).toBe(0)
// })

// test('Should convert 0 C to 32 F', () => {
//     expect(celsiusToFahrenheit(0)).toBe(32)
// })

// // test asynchronous code
// // Jest don't wait for async function
// test('Async test demo', (done) => {
//     setTimeout(()=>{
//         expect(1).toBe(2)
//         // after async operation is done, call done()
//         // jest will wait until done() is called to judge success or failure
//         done()
//     },2000)
// })

// test('Should add two numbers', (done) => {
//     add(2,3).then(sum => {
//         expect(sum).toBe(5)
//         done()
//     })
// }
// )
// test('Should add two numbers async await', async () => {
//     const sum = await add(2,3)
//     expect(sum).toBe(5)
// })